package com.studentapp.config;

public class AppConfig {
    // Database configuration
    public static final String DB_URL = "jdbc:mysql://localhost:3306/student_db";
    public static final String DB_USER = "root";
    public static final String DB_PASSWORD = "root";
    
    // Application settings
    public static final String APP_TITLE = "Student Management System";
    public static final int APP_WIDTH = 1200;
    public static final int APP_HEIGHT = 800;
    
    // UI Constants
    public static final int PADDING = 20;
    public static final int BORDER_RADIUS = 10;
    
    // Colors
    public static final String PRIMARY_COLOR = "#007AFF";
    public static final String SECONDARY_COLOR = "#5AC8FA";
    public static final String SUCCESS_COLOR = "#4CD964";
    public static final String WARNING_COLOR = "#FF9500";
    public static final String ERROR_COLOR = "#FF3B30";
}