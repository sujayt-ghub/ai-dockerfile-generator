# Student Management System

A comprehensive Spring Boot application for managing student information, courses, enrollments, grades, and attendance.

## Prerequisites

- Java Development Kit (JDK) 17+
- Maven 3.6+ or Gradle 7.0+
- MySQL Server 8.0+
- IDE (Spring Tool Suite, IntelliJ IDEA, or Eclipse with Spring plugins)

## Setup Instructions

1. Clone this repository
2. Configure MySQL database (see application.properties)
3. Run the application using Maven: `mvn spring-boot:run` or Gradle: `./gradlew bootRun`
4. Access the application at http://localhost:8080

## Features

- Student registration and profile management
- Course enrollment and management
- Attendance tracking system
- Grade management and reporting
- Administrative dashboard
- Data export functionality
- Search and filter capabilities

## Technology Stack

- Spring Boot 3.1.x
- Spring Data JPA
- Spring Security
- Thymeleaf
- MySQL
- Bootstrap 5
- jQuery
- Chart.js