package com.example.studentmanagement.repository;

import com.example.studentmanagement.model.Course;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CourseRepository extends JpaRepository<Course, Long> {
    
    Optional<Course> findByCourseCode(String courseCode);
    
    List<Course> findByCourseNameContainingIgnoreCase(String courseName);
    
    List<Course> findByInstructorId(Long instructorId);
    
    List<Course> findByStatus(Course.Status status);
    
    @Query("SELECT c FROM Course c JOIN c.students s WHERE s.id = ?1")
    List<Course> findByStudentId(Long studentId);
}