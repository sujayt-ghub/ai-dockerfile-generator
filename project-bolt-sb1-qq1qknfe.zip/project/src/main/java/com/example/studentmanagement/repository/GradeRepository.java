package com.example.studentmanagement.repository;

import com.example.studentmanagement.model.Grade;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface GradeRepository extends JpaRepository<Grade, Long> {
    
    List<Grade> findByStudentId(Long studentId);
    
    List<Grade> findByCourseId(Long courseId);
    
    List<Grade> findByStudentIdAndCourseId(Long studentId, Long courseId);
    
    List<Grade> findByAssignmentType(Grade.AssignmentType assignmentType);
    
    List<Grade> findByStudentIdAndAssignmentType(Long studentId, Grade.AssignmentType assignmentType);
    
    List<Grade> findByCourseIdAndAssignmentType(Long courseId, Grade.AssignmentType assignmentType);
    
    @Query("SELECT AVG(g.score) FROM Grade g WHERE g.student.id = ?1 AND g.course.id = ?2")
    Double findAverageScoreByStudentIdAndCourseId(Long studentId, Long courseId);
    
    @Query("SELECT AVG(g.score) FROM Grade g WHERE g.student.id = ?1")
    Double findAverageScoreByStudentId(Long studentId);
    
    @Query("SELECT AVG(g.score) FROM Grade g WHERE g.course.id = ?1")
    Double findAverageScoreByCourseId(Long courseId);
}