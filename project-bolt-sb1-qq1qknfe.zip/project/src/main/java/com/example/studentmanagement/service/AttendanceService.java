package com.example.studentmanagement.service;

import com.example.studentmanagement.model.Attendance;
import com.example.studentmanagement.model.Course;
import com.example.studentmanagement.model.Student;
import com.example.studentmanagement.repository.AttendanceRepository;
import com.example.studentmanagement.repository.CourseRepository;
import com.example.studentmanagement.repository.StudentRepository;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class AttendanceService {
    
    private final AttendanceRepository attendanceRepository;
    private final StudentRepository studentRepository;
    private final CourseRepository courseRepository;
    
    public List<Attendance> getAllAttendances() {
        return attendanceRepository.findAll();
    }
    
    public Attendance getAttendanceById(Long id) {
        return attendanceRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Attendance record not found with id: " + id));
    }
    
    public List<Attendance> getAttendancesByStudent(Long studentId) {
        return attendanceRepository.findByStudentId(studentId);
    }
    
    public List<Attendance> getAttendancesByCourse(Long courseId) {
        return attendanceRepository.findByCourseId(courseId);
    }
    
    public List<Attendance> getAttendancesByDate(LocalDate date) {
        return attendanceRepository.findByDate(date);
    }
    
    public List<Attendance> getAttendancesByDateRange(LocalDate startDate, LocalDate endDate) {
        return attendanceRepository.findByDateBetween(startDate, endDate);
    }
    
    public List<Attendance> getAttendancesByStudentAndCourse(Long studentId, Long courseId) {
        return attendanceRepository.findByStudentIdAndCourseId(studentId, courseId);
    }
    
    public List<Attendance> getAttendancesByStudentAndDateRange(Long studentId, LocalDate startDate, LocalDate endDate) {
        return attendanceRepository.findByStudentIdAndDateBetween(studentId, startDate, endDate);
    }
    
    @Transactional
    public Attendance recordAttendance(Attendance attendance) {
        // Validate student and course exist
        Student student = studentRepository.findById(attendance.getStudent().getId())
                .orElseThrow(() -> new EntityNotFoundException("Student not found"));
        
        Course course = courseRepository.findById(attendance.getCourse().getId())
                .orElseThrow(() -> new EntityNotFoundException("Course not found"));
        
        // Check if student is enrolled in the course
        if (!student.getCourses().contains(course)) {
            throw new IllegalStateException("Student is not enrolled in this course");
        }
        
        // Set default date to today if not provided
        if (attendance.getDate() == null) {
            attendance.setDate(LocalDate.now());
        }
        
        return attendanceRepository.save(attendance);
    }
    
    @Transactional
    public Attendance updateAttendance(Long id, Attendance attendanceDetails) {
        Attendance attendance = getAttendanceById(id);
        
        attendance.setStatus(attendanceDetails.getStatus());
        attendance.setRemarks(attendanceDetails.getRemarks());
        
        return attendanceRepository.save(attendance);
    }
    
    @Transactional
    public void deleteAttendance(Long id) {
        Attendance attendance = getAttendanceById(id);
        attendanceRepository.delete(attendance);
    }
    
    @Transactional
    public List<Attendance> recordBulkAttendance(Long courseId, LocalDate date, List<Attendance> attendances) {
        // Validate course exists
        Course course = courseRepository.findById(courseId)
                .orElseThrow(() -> new EntityNotFoundException("Course not found"));
        
        // Set course and date for all attendance records
        attendances.forEach(attendance -> {
            attendance.setCourse(course);
            attendance.setDate(date);
        });
        
        return attendanceRepository.saveAll(attendances);
    }
}