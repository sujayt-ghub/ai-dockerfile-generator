package com.example.studentmanagement.repository;

import com.example.studentmanagement.model.Attendance;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface AttendanceRepository extends JpaRepository<Attendance, Long> {
    
    List<Attendance> findByStudentId(Long studentId);
    
    List<Attendance> findByCourseId(Long courseId);
    
    List<Attendance> findByStudentIdAndCourseId(Long studentId, Long courseId);
    
    List<Attendance> findByDate(LocalDate date);
    
    List<Attendance> findByDateBetween(LocalDate startDate, LocalDate endDate);
    
    List<Attendance> findByStudentIdAndDate(Long studentId, LocalDate date);
    
    List<Attendance> findByStudentIdAndDateBetween(Long studentId, LocalDate startDate, LocalDate endDate);
    
    List<Attendance> findByCourseIdAndDate(Long courseId, LocalDate date);
    
    @Query("SELECT a FROM Attendance a WHERE a.student.id = ?1 AND a.course.id = ?2 AND a.date BETWEEN ?3 AND ?4")
    List<Attendance> findByStudentIdAndCourseIdAndDateBetween(Long studentId, Long courseId, LocalDate startDate, LocalDate endDate);
}