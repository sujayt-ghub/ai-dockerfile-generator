package com.example.studentmanagement.service;

import com.example.studentmanagement.model.Student;
import com.example.studentmanagement.repository.StudentRepository;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class StudentService {
    
    private final StudentRepository studentRepository;
    
    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }
    
    public Student getStudentById(Long id) {
        return studentRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Student not found with id: " + id));
    }
    
    public Student getStudentByStudentId(String studentId) {
        return studentRepository.findByStudentId(studentId)
                .orElseThrow(() -> new EntityNotFoundException("Student not found with student ID: " + studentId));
    }
    
    public List<Student> getStudentsByName(String name) {
        return studentRepository.findByFullNameContaining(name);
    }
    
    public List<Student> getStudentsByCourse(Long courseId) {
        return studentRepository.findByCourseId(courseId);
    }
    
    @Transactional
    public Student createStudent(Student student) {
        // Generate student ID if not provided
        if (student.getStudentId() == null || student.getStudentId().isEmpty()) {
            // Simple example: current year + random number
            String year = String.valueOf(java.time.Year.now().getValue());
            String randomPart = String.format("%04d", (int) (Math.random() * 10000));
            student.setStudentId(year + randomPart);
        }
        
        return studentRepository.save(student);
    }
    
    @Transactional
    public Student updateStudent(Long id, Student studentDetails) {
        Student student = getStudentById(id);
        
        student.setFirstName(studentDetails.getFirstName());
        student.setLastName(studentDetails.getLastName());
        student.setDateOfBirth(studentDetails.getDateOfBirth());
        student.setGender(studentDetails.getGender());
        student.setEmail(studentDetails.getEmail());
        student.setPhoneNumber(studentDetails.getPhoneNumber());
        student.setAddress(studentDetails.getAddress());
        student.setStatus(studentDetails.getStatus());
        
        if (studentDetails.getProfilePicture() != null) {
            student.setProfilePicture(studentDetails.getProfilePicture());
        }
        
        return studentRepository.save(student);
    }
    
    @Transactional
    public void deleteStudent(Long id) {
        Student student = getStudentById(id);
        studentRepository.delete(student);
    }
    
    @Transactional
    public Student updateStudentStatus(Long id, Student.Status status) {
        Student student = getStudentById(id);
        student.setStatus(status);
        return studentRepository.save(student);
    }
}