package com.example.studentmanagement.controller;

import com.example.studentmanagement.model.Grade;
import com.example.studentmanagement.service.GradeService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/grades")
@RequiredArgsConstructor
public class GradeController {
    
    private final GradeService gradeService;
    
    @GetMapping
    public ResponseEntity<List<Grade>> getAllGrades() {
        List<Grade> grades = gradeService.getAllGrades();
        return ResponseEntity.ok(grades);
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<Grade> getGradeById(@PathVariable Long id) {
        Grade grade = gradeService.getGradeById(id);
        return ResponseEntity.ok(grade);
    }
    
    @GetMapping("/student/{studentId}")
    public ResponseEntity<List<Grade>> getGradesByStudent(@PathVariable Long studentId) {
        List<Grade> grades = gradeService.getGradesByStudent(studentId);
        return ResponseEntity.ok(grades);
    }
    
    @GetMapping("/course/{courseId}")
    public ResponseEntity<List<Grade>> getGradesByCourse(@PathVariable Long courseId) {
        List<Grade> grades = gradeService.getGradesByCourse(courseId);
        return ResponseEntity.ok(grades);
    }
    
    @GetMapping("/student/{studentId}/course/{courseId}")
    public ResponseEntity<List<Grade>> getGradesByStudentAndCourse(
            @PathVariable Long studentId, 
            @PathVariable Long courseId) {
        List<Grade> grades = gradeService.getGradesByStudentAndCourse(studentId, courseId);
        return ResponseEntity.ok(grades);
    }
    
    @GetMapping("/student/{studentId}/course/{courseId}/average")
    public ResponseEntity<Double> getAverageScoreByStudentAndCourse(
            @PathVariable Long studentId, 
            @PathVariable Long courseId) {
        Double averageScore = gradeService.getAverageScoreByStudentAndCourse(studentId, courseId);
        return ResponseEntity.ok(averageScore);
    }
    
    @GetMapping("/student/{studentId}/average")
    public ResponseEntity<Double> getAverageScoreByStudent(@PathVariable Long studentId) {
        Double averageScore = gradeService.getAverageScoreByStudent(studentId);
        return ResponseEntity.ok(averageScore);
    }
    
    @GetMapping("/course/{courseId}/average")
    public ResponseEntity<Double> getAverageScoreByCourse(@PathVariable Long courseId) {
        Double averageScore = gradeService.getAverageScoreByCourse(courseId);
        return ResponseEntity.ok(averageScore);
    }
    
    @PostMapping
    public ResponseEntity<Grade> recordGrade(@Valid @RequestBody Grade grade) {
        Grade recordedGrade = gradeService.recordGrade(grade);
        return new ResponseEntity<>(recordedGrade, HttpStatus.CREATED);
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<Grade> updateGrade(@PathVariable Long id, @Valid @RequestBody Grade grade) {
        Grade updatedGrade = gradeService.updateGrade(id, grade);
        return ResponseEntity.ok(updatedGrade);
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteGrade(@PathVariable Long id) {
        gradeService.deleteGrade(id);
        return ResponseEntity.noContent().build();
    }
    
    @PostMapping("/bulk/{courseId}")
    public ResponseEntity<List<Grade>> recordBulkGrades(
            @PathVariable Long courseId,
            @RequestParam Grade.AssignmentType assignmentType,
            @Valid @RequestBody List<Grade> grades) {
        List<Grade> recordedGrades = gradeService.recordBulkGrades(courseId, assignmentType, grades);
        return new ResponseEntity<>(recordedGrades, HttpStatus.CREATED);
    }
}