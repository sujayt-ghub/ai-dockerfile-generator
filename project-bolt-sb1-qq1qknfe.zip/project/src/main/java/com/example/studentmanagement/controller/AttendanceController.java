package com.example.studentmanagement.controller;

import com.example.studentmanagement.model.Attendance;
import com.example.studentmanagement.service.AttendanceService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/attendances")
@RequiredArgsConstructor
public class AttendanceController {
    
    private final AttendanceService attendanceService;
    
    @GetMapping
    public ResponseEntity<List<Attendance>> getAllAttendances() {
        List<Attendance> attendances = attendanceService.getAllAttendances();
        return ResponseEntity.ok(attendances);
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<Attendance> getAttendanceById(@PathVariable Long id) {
        Attendance attendance = attendanceService.getAttendanceById(id);
        return ResponseEntity.ok(attendance);
    }
    
    @GetMapping("/student/{studentId}")
    public ResponseEntity<List<Attendance>> getAttendancesByStudent(@PathVariable Long studentId) {
        List<Attendance> attendances = attendanceService.getAttendancesByStudent(studentId);
        return ResponseEntity.ok(attendances);
    }
    
    @GetMapping("/course/{courseId}")
    public ResponseEntity<List<Attendance>> getAttendancesByCourse(@PathVariable Long courseId) {
        List<Attendance> attendances = attendanceService.getAttendancesByCourse(courseId);
        return ResponseEntity.ok(attendances);
    }
    
    @GetMapping("/date/{date}")
    public ResponseEntity<List<Attendance>> getAttendancesByDate(
            @PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        List<Attendance> attendances = attendanceService.getAttendancesByDate(date);
        return ResponseEntity.ok(attendances);
    }
    
    @GetMapping("/date-range")
    public ResponseEntity<List<Attendance>> getAttendancesByDateRange(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
        List<Attendance> attendances = attendanceService.getAttendancesByDateRange(startDate, endDate);
        return ResponseEntity.ok(attendances);
    }
    
    @GetMapping("/student/{studentId}/course/{courseId}")
    public ResponseEntity<List<Attendance>> getAttendancesByStudentAndCourse(
            @PathVariable Long studentId, 
            @PathVariable Long courseId) {
        List<Attendance> attendances = attendanceService.getAttendancesByStudentAndCourse(studentId, courseId);
        return ResponseEntity.ok(attendances);
    }
    
    @PostMapping
    public ResponseEntity<Attendance> recordAttendance(@Valid @RequestBody Attendance attendance) {
        Attendance recordedAttendance = attendanceService.recordAttendance(attendance);
        return new ResponseEntity<>(recordedAttendance, HttpStatus.CREATED);
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<Attendance> updateAttendance(
            @PathVariable Long id, 
            @Valid @RequestBody Attendance attendance) {
        Attendance updatedAttendance = attendanceService.updateAttendance(id, attendance);
        return ResponseEntity.ok(updatedAttendance);
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteAttendance(@PathVariable Long id) {
        attendanceService.deleteAttendance(id);
        return ResponseEntity.noContent().build();
    }
    
    @PostMapping("/bulk/{courseId}")
    public ResponseEntity<List<Attendance>> recordBulkAttendance(
            @PathVariable Long courseId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
            @Valid @RequestBody List<Attendance> attendances) {
        List<Attendance> recordedAttendances = attendanceService.recordBulkAttendance(courseId, date, attendances);
        return new ResponseEntity<>(recordedAttendances, HttpStatus.CREATED);
    }
}