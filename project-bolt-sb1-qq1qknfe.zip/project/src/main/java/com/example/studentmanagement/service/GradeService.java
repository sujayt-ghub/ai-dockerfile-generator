package com.example.studentmanagement.service;

import com.example.studentmanagement.model.Course;
import com.example.studentmanagement.model.Grade;
import com.example.studentmanagement.model.Student;
import com.example.studentmanagement.repository.CourseRepository;
import com.example.studentmanagement.repository.GradeRepository;
import com.example.studentmanagement.repository.StudentRepository;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class GradeService {
    
    private final GradeRepository gradeRepository;
    private final StudentRepository studentRepository;
    private final CourseRepository courseRepository;
    
    public List<Grade> getAllGrades() {
        return gradeRepository.findAll();
    }
    
    public Grade getGradeById(Long id) {
        return gradeRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Grade not found with id: " + id));
    }
    
    public List<Grade> getGradesByStudent(Long studentId) {
        return gradeRepository.findByStudentId(studentId);
    }
    
    public List<Grade> getGradesByCourse(Long courseId) {
        return gradeRepository.findByCourseId(courseId);
    }
    
    public List<Grade> getGradesByStudentAndCourse(Long studentId, Long courseId) {
        return gradeRepository.findByStudentIdAndCourseId(studentId, courseId);
    }
    
    public Double getAverageScoreByStudentAndCourse(Long studentId, Long courseId) {
        return gradeRepository.findAverageScoreByStudentIdAndCourseId(studentId, courseId);
    }
    
    public Double getAverageScoreByStudent(Long studentId) {
        return gradeRepository.findAverageScoreByStudentId(studentId);
    }
    
    public Double getAverageScoreByCourse(Long courseId) {
        return gradeRepository.findAverageScoreByCourseId(courseId);
    }
    
    @Transactional
    public Grade recordGrade(Grade grade) {
        // Validate student and course exist
        Student student = studentRepository.findById(grade.getStudent().getId())
                .orElseThrow(() -> new EntityNotFoundException("Student not found"));
        
        Course course = courseRepository.findById(grade.getCourse().getId())
                .orElseThrow(() -> new EntityNotFoundException("Course not found"));
        
        // Check if student is enrolled in the course
        if (!student.getCourses().contains(course)) {
            throw new IllegalStateException("Student is not enrolled in this course");
        }
        
        return gradeRepository.save(grade);
    }
    
    @Transactional
    public Grade updateGrade(Long id, Grade gradeDetails) {
        Grade grade = getGradeById(id);
        
        grade.setScore(gradeDetails.getScore());
        grade.setComments(gradeDetails.getComments());
        
        return gradeRepository.save(grade);
    }
    
    @Transactional
    public void deleteGrade(Long id) {
        Grade grade = getGradeById(id);
        gradeRepository.delete(grade);
    }
    
    @Transactional
    public List<Grade> recordBulkGrades(Long courseId, Grade.AssignmentType assignmentType, List<Grade> grades) {
        // Validate course exists
        Course course = courseRepository.findById(courseId)
                .orElseThrow(() -> new EntityNotFoundException("Course not found"));
        
        // Set course and assignment type for all grade records
        grades.forEach(grade -> {
            grade.setCourse(course);
            grade.setAssignmentType(assignmentType);
        });
        
        return gradeRepository.saveAll(grades);
    }
}