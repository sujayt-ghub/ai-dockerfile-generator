package com.example.studentmanagement.repository;

import com.example.studentmanagement.model.Instructor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface InstructorRepository extends JpaRepository<Instructor, Long> {
    
    Optional<Instructor> findByInstructorId(String instructorId);
    
    Optional<Instructor> findByEmail(String email);
    
    List<Instructor> findByDepartment(String department);
    
    @Query("SELECT i FROM Instructor i WHERE CONCAT(i.firstName, ' ', i.lastName) LIKE %?1%")
    List<Instructor> findByFullNameContaining(String fullName);
    
    List<Instructor> findByStatus(Instructor.Status status);
}