-- Insert roles
INSERT INTO roles (name) VALUES ('ROLE_ADMIN');
INSERT INTO roles (name) VALUES ('ROLE_INSTRUCTOR');
INSERT INTO roles (name) VALUES ('ROLE_STUDENT');
INSERT INTO roles (name) VALUES ('ROLE_USER');

-- Insert admin user
INSERT INTO users (username, password, email, full_name, enabled, created_at, updated_at)
VALUES ('admin', '$2a$10$eDIJO.xKqZ5DTM1SQ1NB9uLQZL3f0YydJbIpUGI1GcnQKJRZb6592', 'admin@example.com', 'System Administrator', true, NOW(), NOW());

-- Assign admin role to admin user
INSERT INTO user_roles (user_id, role_id) VALUES (1, 1);

-- Insert departments
INSERT INTO instructors (instructor_id, first_name, last_name, email, phone_number, department, qualification, status, created_at, updated_at)
VALUES 
('INS001', 'John', 'Smith', 'john.smith@example.com', '+1234567890', 'Computer Science', 'PhD in Computer Science', 'ACTIVE', NOW(), NOW()),
('INS002', 'Emily', 'Johnson', 'emily.johnson@example.com', '+1234567891', 'Mathematics', 'PhD in Mathematics', 'ACTIVE', NOW(), NOW()),
('INS003', 'Michael', 'Brown', 'michael.brown@example.com', '+1234567892', 'Physics', 'PhD in Physics', 'ACTIVE', NOW(), NOW());

-- Insert courses
INSERT INTO courses (course_code, course_name, description, credit_hours, instructor_id, status, created_at, updated_at)
VALUES 
('CS101', 'Introduction to Programming', 'A beginner-friendly introduction to programming concepts using Java.', 3, 1, 'ACTIVE', NOW(), NOW()),
('CS201', 'Data Structures', 'Study of fundamental data structures and their applications.', 4, 1, 'ACTIVE', NOW(), NOW()),
('MATH101', 'Calculus I', 'Introduction to differential and integral calculus.', 4, 2, 'ACTIVE', NOW(), NOW()),
('PHYS101', 'Physics I', 'Introduction to mechanics and thermodynamics.', 4, 3, 'ACTIVE', NOW(), NOW());

-- Insert students
INSERT INTO students (student_id, first_name, last_name, date_of_birth, gender, email, phone_number, address, status, created_at, updated_at)
VALUES 
('2023001', 'Alice', 'Williams', '2000-05-15', 'Female', 'alice.williams@example.com', '+1987654320', '123 College St, College Town', 'ACTIVE', NOW(), NOW()),
('2023002', 'Bob', 'Jones', '2001-08-22', 'Male', 'bob.jones@example.com', '+1987654321', '456 University Ave, College Town', 'ACTIVE', NOW(), NOW()),
('2023003', 'Charlie', 'Davis', '2000-11-10', 'Male', 'charlie.davis@example.com', '+1987654322', '789 Campus Rd, College Town', 'ACTIVE', NOW(), NOW()),
('2023004', 'Diana', 'Miller', '2002-02-28', 'Female', 'diana.miller@example.com', '+1987654323', '101 Student Ln, College Town', 'ACTIVE', NOW(), NOW());

-- Enroll students in courses
INSERT INTO student_course (student_id, course_id) VALUES (1, 1);
INSERT INTO student_course (student_id, course_id) VALUES (1, 3);
INSERT INTO student_course (student_id, course_id) VALUES (2, 1);
INSERT INTO student_course (student_id, course_id) VALUES (2, 2);
INSERT INTO student_course (student_id, course_id) VALUES (3, 2);
INSERT INTO student_course (student_id, course_id) VALUES (3, 4);
INSERT INTO student_course (student_id, course_id) VALUES (4, 3);
INSERT INTO student_course (student_id, course_id) VALUES (4, 4);

-- Insert attendance records (for the past week)
INSERT INTO attendances (student_id, course_id, date, status, created_at, updated_at)
VALUES 
(1, 1, CURRENT_DATE - 7, 'PRESENT', NOW(), NOW()),
(1, 3, CURRENT_DATE - 7, 'PRESENT', NOW(), NOW()),
(2, 1, CURRENT_DATE - 7, 'PRESENT', NOW(), NOW()),
(2, 2, CURRENT_DATE - 7, 'ABSENT', NOW(), NOW()),
(3, 2, CURRENT_DATE - 7, 'PRESENT', NOW(), NOW()),
(3, 4, CURRENT_DATE - 7, 'PRESENT', NOW(), NOW()),
(4, 3, CURRENT_DATE - 7, 'LATE', NOW(), NOW()),
(4, 4, CURRENT_DATE - 7, 'PRESENT', NOW(), NOW());

-- Insert grades
INSERT INTO grades (student_id, course_id, assignment_type, score, comments, created_at, updated_at)
VALUES 
(1, 1, 'QUIZ', 85.0, 'Good understanding of basic concepts', NOW(), NOW()),
(1, 3, 'QUIZ', 78.0, 'Needs to work on derivatives', NOW(), NOW()),
(2, 1, 'QUIZ', 92.0, 'Excellent work', NOW(), NOW()),
(2, 2, 'ASSIGNMENT', 88.0, 'Well-structured code', NOW(), NOW()),
(3, 2, 'ASSIGNMENT', 76.0, 'Code works but lacks comments', NOW(), NOW()),
(3, 4, 'MID_TERM', 81.0, 'Good grasp of concepts', NOW(), NOW()),
(4, 3, 'MID_TERM', 95.0, 'Outstanding performance', NOW(), NOW()),
(4, 4, 'QUIZ', 72.0, 'Needs improvement in problem-solving', NOW(), NOW());